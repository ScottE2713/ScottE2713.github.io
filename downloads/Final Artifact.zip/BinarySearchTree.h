#ifndef BINARY_SEARCH_TREE_H
#define BINARY_SEARCH_TREE_H

#include "Course.h"
#include <vector>

// TreeNode structure for Binary Search Tree
struct TreeNode {
    Course course; // Course data stored in this node
    TreeNode* left; // Pointer to left subtree
    TreeNode* right; // Pointer to right subtree

    // Constructor
    TreeNode(const Course& crs);
};

class BinarySearchTree {
private:
    void inOrderTraversal(TreeNode* node, std::vector<std::string>& courseNumbers) const; // Perform in-order traversal of the tree to collect course numbers

public:
    TreeNode* root; // Root node of the tree
    BinarySearchTree(); // Constructor initializes the tree as empty
    void insert(const Course& course); // Insert a course into the binary search tree
    TreeNode* find(const std::string& courseNumber) const; // Find a course by course number
    std::vector<std::string> getSortedCourseNumbers() const; // Get sorted course numbers using in-order traversal
	std::vector<Course> searchByPrefix(const std::string& prefix) const; // Search for courses with a specific prefix

};

#endif
