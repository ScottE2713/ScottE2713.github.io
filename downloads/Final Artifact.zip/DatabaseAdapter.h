#ifndef DATABASE_ADAPTER_H
#define DATABASE_ADAPTER_H

#include "Course.h"
#include <string>
#include <vector>
#include <sqlite3.h>

class DatabaseAdapter {
private:
	sqlite3* db; // Pointer to the SQLite database connection

public:
	DatabaseAdapter(const std::string& dbPath); // Constructor that opens the database at the specified path
	~DatabaseAdapter(); // Destructor that closes the database connection

	bool open(); // Opens the database connection and returns true if successful
	void close(); // Closes the database connection if it is open

	std::vector<Course> getAllCourses(); // Retrieves all courses from the database and returns them as a vector of Course objects
	bool getCourseWithPrerequisites(const std::string& courseNumber, Course& course); // Retrieves a course with its prerequisites from the database based on the course number
	std::vector<Course> searchCoursesByPrefix(const std::string& prefix); // Searches for courses in the database that match a given prefix and returns them as a vector of Course objects

	bool addCourse(const Course& course); // Adds a new course to the database, including its prerequisites
	bool updateCourse(const Course& course); // Updates an existing course in the database, including its prerequisites
	bool updatePrerequisites(const std::string& courseNumber, const std::vector<std::string>& prereqs); // Updates the prerequisites for a course in the database based on the course number and a vector of prerequisite course numbers
	bool deleteCourse(const std::string& courseNumber); // Deletes a course from the database based on the course number

private:
	bool executeQuery(const std::string& sql); // Executes a SQL query and returns true if successful
};

#endif
