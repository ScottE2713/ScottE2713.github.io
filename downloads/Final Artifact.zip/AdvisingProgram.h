#ifndef ADVISING_PROGRAM_H
#define ADVISING_PROGRAM_H

#include "BinarySearchTree.h"
#include <string>
#include "DatabaseAdapter.h" // Include DatabaseAdapter for database operations

// AdvisingProgram class manages the user interface and interaction
class AdvisingProgram {
private:
    BinarySearchTree bst; // Binary search tree to store course information
    DatabaseAdapter db{"advising.db"}; // Database adapter for database operations
	bool loadedFromFile = false; // Flag to indicate if data was loaded from a file

    void loadCourseDataFromFile(); // Loads course data from a file into the BST
    void printCourseList() const; // Prints all courses in the BST in alphanumeric order
    void printCourse(const std::string& courseNumber) const; // Prints details for a specific course
    void searchCoursesByPrefix() const; // Allow users to search for all courses that start with a given prefix
	void loadCourseDataFromDatabase(); // Enhancement 3: Loads course data from the database into the BST       
	void seedDatabaseWithBST();   // Enhancement 3: Seeds the database with courses from the BST   
	void updateCourseInDatabase(); // Enhancement 3: Updates a course in the database
	void deleteCourseFromDatabase(); // Enhancement 3: Deletes a course from the database
	void addCourseToDatabase(); // Enhancement 3: Adds a course to the database


public:
    void displayMenu(); // Displays user interface menu and handles user input
	AdvisingProgram(); // Constructor initializes the AdvisingProgram and connects to the database
	~AdvisingProgram(); // Destructor closes the database connection
};

#endif
