//============================================================================
// File        : BinarySearchTree.cpp
// Author      : Scott Enos
// Description : Implements the BinarySearchTree and TreeNode structures.
//               Provides insertion, search, and in-order traversal logic
//               for managing the course data.
//============================================================================

#include "BinarySearchTree.h"
#include <algorithm>
#include "StringUtils.h"

using namespace std;

// Constructor to initialize a node with a course
TreeNode::TreeNode(const Course& crs) : course(crs), left(nullptr), right(nullptr) {}

// Constructor initializes the tree as empty
BinarySearchTree::BinarySearchTree() : root(nullptr) {}

// Insert a course into the binary search tree
void BinarySearchTree::insert(const Course& course) {
    TreeNode** cur = &root;
	while (*cur) { // Traverse the tree to find the correct position
        const string& curCourseNumber = (*cur)->course.courseNumber;
		if (course.courseNumber < curCourseNumber) { // If the new course number is less, go left
            cur = &((*cur)->left);
		}
		else { // If the new course number is greater or equal, go right
            cur = &((*cur)->right);
        }
    }
	*cur = new TreeNode(course); // Create a new node at the found position
}

// Find a course by course number
TreeNode* BinarySearchTree::find(const string& courseNumber) const {
    TreeNode* cur = root;
	while (cur) { // Traverse the tree to find the course
		if (courseNumber == cur->course.courseNumber) { // Course found, return the node
            return cur;
		}
		else if (courseNumber < cur->course.courseNumber) { // If the course number is less, go left
            cur = cur->left;
		}
		else { // If the course number is greater, go right
            cur = cur->right;
        }
    }
	return nullptr; // Course not found, return nullptr
}

// Perform in-order traversal of the tree to collect course numbers
void BinarySearchTree::inOrderTraversal(TreeNode* node, vector<string>& courseNumbers) const {
	if (!node) return; // If the node is null, return
	inOrderTraversal(node->left, courseNumbers); // Traverse left subtree first
	courseNumbers.push_back(node->course.courseNumber); // Add the course number to the list
	inOrderTraversal(node->right, courseNumbers); // Traverse right subtree next
}

// Get sorted course numbers using in-order traversal
vector<string> BinarySearchTree::getSortedCourseNumbers() const {
    vector<string> courseNumbers;
	inOrderTraversal(root, courseNumbers); // Collect course numbers in sorted order
	sort(courseNumbers.begin(), courseNumbers.end()); // Ensure the course numbers are sorted
    return courseNumbers;
}


// Search for courses with a specific prefix
static void searchByPrefixHelper(TreeNode* node, const string& prefix, vector<Course>& results) {
	if (!node) return; // If the node is null, return

    // Traverse left subtree
    searchByPrefixHelper(node->left, prefix, results);

	string courseNum = toUpper(trim(node->course.courseNumber)); // Get the course number from the node
	string upperPrefix = toUpper(trim(prefix)); // Get the prefix to search for
	

    // If course number starts with prefix, add to results
    if (courseNum.find(upperPrefix) == 0) {
        results.push_back(node->course);
    }

	// Traverse right subtree - recursively search for courses with the prefix
    searchByPrefixHelper(node->right, prefix, results);
}

// Search the entire tree for courses matching a prefix
vector<Course> BinarySearchTree::searchByPrefix(const string& prefix) const {
    vector<Course> results;
	searchByPrefixHelper(root, prefix, results); // Start the recursive search from the root
    return results;
}
