//============================================================================
// File        : AdvisingProgram.cpp
// Author      : Scott Enos
// Description : Implements the AdvisingProgram class, which manages user
//               interaction, menu options, and course data handling.
//============================================================================

#include "AdvisingProgram.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <regex>
#include <stdexcept>
#include "StringUtils.h"
#include <DatabaseAdapter.h>

using namespace std;

// Constructor initializes the AdvisingProgram and connects to the database
AdvisingProgram::AdvisingProgram() : db("advising.db") {
    if (!db.open()) {
        std::cerr << "[ERROR] Failed to open database.\n";
    }
    else {
        std::cout << "[INFO] Database connected.\n";
    }
}

// Destructor closes the database connection
AdvisingProgram::~AdvisingProgram() {
	db.close(); // Close the database connection when the program ends
}


// Loads course data from a file into the binary search tree
void AdvisingProgram::loadCourseDataFromFile() {
	int maxCourses = 1000; // Maximum number of courses to load - prevent excessive memory usage
	int loadedCourses = 0; // Counter for loaded courses
	
    if (bst.root && loadedCourses >= maxCourses) { // If the binary search tree already has data, check if it exceeds maxCourses
		cout << "Maximum course limit reached. Cannot load more courses." << endl;
		return; // Exit if the maximum number of courses is reached
	}

	if (bst.root) { // If the binary search tree already has data, prompt user to confirm reloading
		char choice;
		cout << "Data already loaded. Do you want to reload? (y/n): ";
		cin >> choice;
		cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear the input buffer
		if (choice != 'y' && choice != 'Y') {
			cout << "Data not reloaded." << endl;
			return; // Exit if user does not want to reload data
		}
		bst = BinarySearchTree(); // Reset the binary search tree
	}

    string filename = "..\\ABCU_Advising_Program_Input.txt"; // Relative path to the data file
    try{
        ifstream file(filename);
        if (!file.is_open()) {
			cout << "Error: File '" << filename << "' cannot be opened. Please check the file path." << endl; // Exit if the file cannot be opened
            return;
        }

        string line, courseNumber, title, prerequisite;
		while (getline(file, line)) { // Read each line from the file
			if (line.empty()) continue; // Skip empty lines

			if (loadedCourses >= maxCourses) { // Check if the maximum number of courses has been reached
				cout << "Maximum course limit reached. Stopping data load." << endl;
				break; // Exit the loop if the limit is reached
			}

			stringstream ss(line); // Use stringstream to parse the line
			getline(ss, courseNumber, ','); // Read course number until the first comma
			getline(ss, title, ','); // Read course title until the next comma
             
			// Trim whitespace from course number and title and convert to uppercase
            courseNumber = removeHyphens(toUpper(trim(courseNumber)));
            title = trim(title);

			if (title.empty()) { // Check if the course title is empty
                cout << "Invalid or missing course title for course: " << courseNumber << endl;
                continue; // Skip courses with blank titles
            }

            // Validate course number format using regex
			static const regex validCourseFormat("[A-Z]{2,4}\\d{3}"); // Example format: CS101, MATH201, etc.
            if (!regex_match(courseNumber, validCourseFormat)) {
                cout << "Invalid course number format: " << courseNumber << endl; 
                continue;
            }
            Course course{courseNumber, title};

            while (getline(ss, prerequisite, ',')) {
                // Ensure prerequisite is formatted correctly
				prerequisite = removeHyphens(toUpper(trim(prerequisite))); // Trim whitespace from prerequisite and convert to uppercase
                if (!regex_match(prerequisite, validCourseFormat)) {
                    cout << "Invalid prerequisite format: " << prerequisite << endl;
                    continue; // Skip this prereq
                }
				course.prerequisites.push_back(prerequisite); // Add prerequisite to the course
            }

            // Check if the course already exists in the binary search tree
            // If it does, skip inserting it and print a warning
            if (bst.find(course.courseNumber)) {
                cout << "Warning: Duplicate course '" << course.courseNumber << "' found. Skipping." << endl;
                continue;
            }

            bst.insert(course); // Insert course into the binary search tree
			loadedCourses++; // Increment the counter for loaded courses
        }
        file.close();
        cout << "Data loaded successfully." << endl;
    }
    catch (const ifstream::failure& e) { // Catch file-related exceptions
        cout << "Exception opening/reading file: " << e.what() << endl;
    }
    catch (const exception& e) { // Catch other standard exceptions
        cout << "An error occurred: " << e.what() << endl;
    }
    catch (...) { // Catch any other unexpected exceptions
        cout << "An unexpected error occurred while loading course data." << endl;
    }
}

// Prints all courses in alphanumeric order
void AdvisingProgram::printCourseList() const {
	if (!bst.root) { // Check if the binary search tree is empty
        cout << "No course data available. Please load the data first." << endl;
        return;
    }

    vector<string> courseNumbers = bst.getSortedCourseNumbers(); // Collect all course numbers through in-order traversal

	for (const string& num : courseNumbers) { // Iterate through each course number
        TreeNode* node = bst.find(num);
		if (node) { // If the node is found, print the course title
            cout << num << ": " << node->course.title << endl;
        }
    }
}

// Prints detailed information about a specific course
void AdvisingProgram::printCourse(const string& courseNumber) const {
	string trimmedCourseNumber = removeHyphens(toUpper(trim(courseNumber))); // Trim whitespace and convert to uppercase for consistency


    // Ensure the course number is not empty and matches the expected format
    static const regex validCourseFormat("[A-Z]{2,4}\\d{3}");
    if (trimmedCourseNumber.empty()) {
        cout << "Error: Course number cannot be empty." << endl;
        return;
    }
	if (!regex_match(trimmedCourseNumber, validCourseFormat)) { // Validate course number format
        cout << "Invalid course number format." << endl;
        return;
    }

	TreeNode* node = bst.find(trimmedCourseNumber); // Find the course in the binary search tree
	if (!node) { // If the course is not found, print an error message
        cout << "Course '" << trimmedCourseNumber << "' not found." << endl;
        return;
    }

    const Course& course = node->course;

    // Validate that the course title and number is not empty
    if(course.courseNumber.empty()) {
        cout << "Error: Course number is empty." << endl;
        return;
    }
    if(course.title.empty()) {
        cout << "Error: Course title is empty." << endl;
        return;
    }

    cout << "Course: " << course.title << " (" << course.courseNumber << ")" << endl;
	if (course.prerequisites.empty()) { // If there are no prerequisites, print a message saying that
        cout << "Prerequisites: None" << endl;
	}
	else { // If there are prerequisites, print them
        cout << "Prerequisites: ";
		for (const string& prereq : course.prerequisites) { // Iterate through each prerequisite
			cout << prereq << " - "; // Print the prerequisite course number
            TreeNode* prereqNode = bst.find(prereq);
			if (prereqNode) { // If the prerequisite is found, print its title
                cout << prereqNode->course.title << ", ";
			}
			else { // If the prerequisite is not found, print a message
                cout << "Not found in current data, ";
            }
        }
        cout << "\b\b " << endl; // Remove the last comma
    }
}

// Prompts user for a prefix and displays all courses whose course numbers start with it
void AdvisingProgram::searchCoursesByPrefix() const {
    string prefix;
    cout << "Enter course prefix (e.g., 'CS'): ";
	getline(cin, prefix); // Read the prefix input from the user

    // Trim whitespace, convert to uppercase, and check if input is valid
    prefix = removeHyphens(toUpper(trim(prefix)));
	if (prefix.empty()) { // If the prefix is empty, print an error message and return
        cout << "Prefix cannot be empty." << endl;
        return;
    }

    // Search the BST for matching courses
    vector<Course> results = bst.searchByPrefix(prefix);
	if (results.empty()) { // If no courses match the prefix, print a message
        cout << "No courses found with prefix '" << prefix << "'." << endl;
        return;
    }

    // Display all matching courses
    cout << "Courses found with prefix '" << prefix << "':" << endl;
	for (const Course& c : results) { // Iterate through the results and print each course
        cout << c.courseNumber << ": " << c.title << endl;
    }
}

// Enhancement 3: Loads course data from the database into the binary search tree
void AdvisingProgram::loadCourseDataFromDatabase() {
    if (!db.open()) {
        cout << "Database connection failed.\n";
        return;
    }

    bst = BinarySearchTree(); // clear current memory

	vector<Course> courses = db.getAllCourses(); // Retrieve all courses from the database
	for (Course& course : courses) { // Iterate through each course retrieved from the database
		db.getCourseWithPrerequisites(course.courseNumber, course); // Get course details including prerequisites
		bst.insert(course); // Insert the course into the binary search tree
    }

    cout << "Data loaded from database into memory.\n";
}

// Enhancement 3: Seeds the database with courses from the binary search tree
void AdvisingProgram::seedDatabaseWithBST() {
    if (!db.open()) {
        cout << "Database connection failed.\n";
        return;
    }

	vector<string> courseNumbers = bst.getSortedCourseNumbers(); // Get all course numbers from the binary search tree in sorted order
	for (const string& num : courseNumbers) { // Iterate through each course number
		TreeNode* node = bst.find(num); // Find the course node in the binary search tree
		if (node) { // If the course node is found, insert it into the database
            db.addCourse(node->course); // use your existing DB insert logic
        }
    }

    cout << "Database seeded with in-memory course data.\n";
}

// Enhancement 3: Updates a course in the database
void AdvisingProgram::updateCourseInDatabase() {
    string courseNumber;
	cout << "Enter course number to update (or press Enter to cancel): "; // Prompt user for course number to update
    getline(cin, courseNumber); 
	courseNumber = removeHyphens(toUpper(trim(courseNumber))); // Trim whitespace and convert to uppercase for consistency

	if (courseNumber.empty()) { // If the course number is empty, print a message and return
        cout << "Update cancelled.\n";
        return;
    }

    Course updatedCourse;
	updatedCourse.courseNumber = courseNumber; // Set the course number for the updated course

	cout << "Enter new title for the course: "; // Prompt user for new course title
    getline(cin, updatedCourse.title);  

	cout << "Enter prerequisites separated by commas (or leave blank for none): "; // Prompt user for prerequisites
    string prereqInput;
    getline(cin, prereqInput);

	if (!prereqInput.empty()) { // If prerequisites are provided, split them by commas and process each one
        stringstream ss(prereqInput); 
        string prereq;
        while (getline(ss, prereq, ',')) { 
			prereq = removeHyphens(toUpper(trim(prereq))); // Trim whitespace and convert to uppercase for consistency
            if (!prereq.empty()) {
				updatedCourse.prerequisites.push_back(prereq); // Add the prerequisite to the updated course
            }
        }
    }

    if (db.updateCourse(updatedCourse)) {
        cout << "Course updated successfully.\n";
    }
    else {
        cout << "Failed to update course.\n";
    }
}

// Enhancement 3: Deletes a course from the database
void AdvisingProgram::deleteCourseFromDatabase() {
    string courseNumber;
	cout << "Enter course number to delete (or press Enter to cancel): "; // Prompt user for course number to delete
    getline(cin, courseNumber); 
	courseNumber = removeHyphens(toUpper(trim(courseNumber))); // Trim whitespace and convert to uppercase for consistency

    if (courseNumber.empty()) {
        cout << "Delete cancelled.\n";
        return;
    }

    if (db.deleteCourse(courseNumber)) {
        cout << "Course deleted successfully.\n";
    }
    else {
        cout << "Failed to delete course or course not found.\n";
    }
}

// Enhancement 3: Adds a new course to the database
void AdvisingProgram::addCourseToDatabase() {
    string courseNumber;
    cout << "Enter course number to add (or press Enter to cancel): ";
    getline(cin, courseNumber);
    courseNumber = sanitize(courseNumber); // Use centralized string utils

    if (courseNumber.empty()) {
        cout << "Add cancelled.\n";
        return;
    }

    // Check if course already exists
    Course temp;
    if (db.getCourseWithPrerequisites(courseNumber, temp)) {
        cout << "Course already exists in the database.\n";
        return;
    }

    Course newCourse;
    newCourse.courseNumber = courseNumber;

    cout << "Enter title for the new course: ";
    getline(cin, newCourse.title);

    cout << "Enter prerequisites separated by commas (or leave blank for none): ";
    string prereqInput;
    getline(cin, prereqInput);

    if (!prereqInput.empty()) {
        stringstream ss(prereqInput);
        string prereq;
        while (getline(ss, prereq, ',')) {
            prereq = sanitize(prereq);
            if (prereq.empty()) continue;

            // Validate prerequisite exists in DB
            Course dummy;
            if (!db.getCourseWithPrerequisites(prereq, dummy)) {
                cout << "Prerequisite '" << prereq << "' does not exist and will be skipped.\n";
                continue;
            }

            newCourse.prerequisites.push_back(prereq);
        }
    }

    if (db.addCourse(newCourse)) {
        cout << "Course added successfully.\n";
    }
    else {
        cout << "Failed to add course.\n";
    }
}

// Displays the main menu and handles user interactions
void AdvisingProgram::displayMenu() {
    int choice;
    string courseNumber;
    do {
        // Updated menu prompt 
        cout << "\nMenu:\n1) Load Data From File \n2) Load Data From DB \n3) Seed DB With Loaded Data \n4) Print Course List \n5) Print Course \n6) Search by Prefix \n7) Add Course (DB Only) \n8) Update Course (DB Only) \n9) Delete Course (DB Only) \n10) Exit \nEnter your choice: ";
        while (!(cin >> choice)) {
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard incorrect input
            cout << "Invalid input. Please enter a number: ";
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear the input buffer

        switch (choice) {
            case 1:
                loadCourseDataFromFile(); // Option to load data
				loadedFromFile = true; // Set flag to indicate data was loaded from file
                break;
			case 2: // Update for Enhancement 3 - Load data from database
				loadCourseDataFromDatabase(); // Load course data from the database into the binary search tree
				loadedFromFile = false; // Set flag to indicate data was loaded from the database
                break;
			case 3: // Update for Enhancement 3 - Seed database with loaded data
				if (!bst.root) { // Check if the binary search tree is empty
					cout << "No course data available in memory. Please load the data first." << endl;
					continue; // Skip to the next iteration if no data is loaded
				}
				seedDatabaseWithBST(); // Seed the database with courses from the binary search tree
				loadedFromFile = false; // Set flag to indicate data was loaded from the database (Since we're now synced with db)
                break;
            case 4:
                printCourseList(); // Option to print course list
                break;
            case 5:
				if (!bst.root) { // Check if the binary search tree is empty
					cout << "No course data available. Please load the data first." << endl;
					continue; // Skip to the next iteration if no data is loaded
				}
                cout << "Enter the course number: ";
				getline(cin, courseNumber); // Read course number input from the user
                printCourse(courseNumber); // Option to print specific course information
                break;
			case 6:
                if (!bst.root) { // Check if the binary search tree is empty
                    cout << "No course data available. Please load the data first." << endl;
                }
                else {
                    searchCoursesByPrefix(); // Option to search courses by prefix
                }
				break;
			case 7: // Update for Enhancement 3 - Add course to database
                if (!db.open()) { // Check if the database connection is open
                    cout << "Database connection failed. Cannot update course." << endl;
                    continue; // Skip to the next iteration if the database connection is not open
                }
                if (!bst.root) { // Check if the binary search tree is empty
                    cout << "No course data available. Please load the data first." << endl;
                    continue; // Skip to the next iteration if no data is loaded
                }
                if (loadedFromFile) { // Check if data was loaded from a file
                    cout << "Data loaded from file. Please load data from the database to update." << endl;
                    continue; // Skip to the next iteration if data was loaded from a file
                }
				addCourseToDatabase(); // Adds a course to the database
				loadCourseDataFromDatabase(); // Reload data from the database to ensure BST is up-to-date
				loadedFromFile = false; // Set flag to indicate data was loaded from the database
                break;
            case 8:
				if (!db.open()) { // Check if the database connection is open
					cout << "Database connection failed. Cannot update course." << endl;
					continue; // Skip to the next iteration if the database connection is not open
				}
				if (!bst.root) { // Check if the binary search tree is empty
					cout << "No course data available. Please load the data first." << endl;
					continue; // Skip to the next iteration if no data is loaded
				}
				if (loadedFromFile) { // Check if data was loaded from a file
					cout << "Data loaded from file. Please load data from the database to update." << endl;
					continue; // Skip to the next iteration if data was loaded from a file
				}
				updateCourseInDatabase(); // Option to update a course in the database
				loadCourseDataFromDatabase(); // Reload data from the database to ensure BST is up-to-date
				loadedFromFile = false; // Set flag to indicate data was loaded from the database
                break;
            case 9:
                if (!db.open()) { // Check if the database connection is open
                    cout << "Database connection failed. Cannot update course." << endl;
                    continue; // Skip to the next iteration if the database connection is not open
                }
                if (!bst.root) { // Check if the binary search tree is empty
                    cout << "No course data available. Please load the data first." << endl;
                    continue; // Skip to the next iteration if no data is loaded
                }
                if (loadedFromFile) { // Check if data was loaded from a file
                    cout << "Data loaded from file. Please load data from the database to update." << endl;
                    continue; // Skip to the next iteration if data was loaded from a file
                }
				deleteCourseFromDatabase(); // Deletes a course from the database
                loadCourseDataFromDatabase(); // Reload data from the database to ensure BST is up-to-date
                loadedFromFile = false; // Set flag to indicate data was loaded from the database
                break;
            case 10:
                cout << "Exiting program." << endl;
				db.close(); // Close the database connection before exiting
                break;
            default:
                cout << "Invalid choice. Please enter a valid option." << endl;
                break;
        }
    } while (choice != 10); // Updated to account for new menu item -- Continue displaying the menu until the user selects 'Exit'
}
