#include "DatabaseAdapter.h"
#include <iostream>
#include "sqlite3.h"


using namespace std;

// DatabaseAdapter constructor opens the SQLite database at the specified path
DatabaseAdapter::DatabaseAdapter(const string& dbPath) {
	if (sqlite3_open(dbPath.c_str(), &db)) { // Attempt to open the database
        cerr << "Error opening DB: " << sqlite3_errmsg(db) << endl; 
		db = nullptr; // Set db to nullptr if opening fails
    }

	if (db) { // If the database is successfully opened, initialize the schema
        const char* sqlSchema =
			"CREATE TABLE IF NOT EXISTS Courses (" 
            "CourseNumber TEXT PRIMARY KEY, "
			"Title TEXT NOT NULL);" // Create Courses table with CourseNumber as primary key and Title as a required field if it doesn't exist
            "CREATE TABLE IF NOT EXISTS Prerequisites ("
            "CourseNumber TEXT NOT NULL, "
            "Prerequisite TEXT NOT NULL, "
			"FOREIGN KEY (CourseNumber) REFERENCES Courses(CourseNumber));"; // Create Prerequisites table with foreign key reference to Courses table if it doesn't exist

		char* errMsg = nullptr; // Pointer to hold error message if the schema creation fails
		if (sqlite3_exec(db, sqlSchema, nullptr, nullptr, &errMsg) != SQLITE_OK) { // Execute the SQL schema creation
			std::cerr << "Failed to initialize database schema: " << errMsg << std::endl; // Print error message if schema creation fails
			sqlite3_free(errMsg); // Free the error message memory if schema creation fails
        }
    }
}

// Destructor closes the database connection if it is open
DatabaseAdapter::~DatabaseAdapter() {
    close();
}

// Opens the database connection and returns true if successful
bool DatabaseAdapter::open() {
    return db != nullptr;
}

// Closes the database connection if it is open
void DatabaseAdapter::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}


// Retrieves all courses from the database and returns them as a vector of Course objects
vector<Course> DatabaseAdapter::getAllCourses() {
	vector<Course> courses; // Vector to hold all courses
	const char* sql = "SELECT CourseNumber, Title FROM Courses"; // SQL query to select all courses
	sqlite3_stmt* stmt; // SQLite statement object

	if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) { // Prepare the SQL statement
		while (sqlite3_step(stmt) == SQLITE_ROW) { // Execute the statement and iterate through the results
            Course c;
			c.courseNumber = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)); // Get course number from the first column
			c.title = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)); // Get course title from the second column
			courses.push_back(c); // Add the course to the vector
        }
    }
	sqlite3_finalize(stmt); // Finalize the statement to release resources
    return courses;
}

// Retrieves a course with its prerequisites from the database based on the course number
bool DatabaseAdapter::getCourseWithPrerequisites(const string& courseNumber, Course& course) {
	const char* sqlCourse = "SELECT Title FROM Courses WHERE CourseNumber = ?"; // SQL query to get course title
	const char* sqlPrereqs = "SELECT Prerequisite FROM Prerequisites WHERE CourseNumber = ?"; // SQL query to get prerequisites for the course
    sqlite3_stmt* stmt;

    // Get course title
    if (sqlite3_prepare_v2(db, sqlCourse, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement
		if (sqlite3_step(stmt) == SQLITE_ROW) { // Execute the statement and check if a row is returned
            course.courseNumber = courseNumber;
			course.title = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)); // Get the course title from the first column
        }
        else {
			sqlite3_finalize(stmt); // Finalize the statement if no course is found
            return false;
        }
    }
	sqlite3_finalize(stmt); // Finalize the statement to release resources

    // Get prerequisites
    if (sqlite3_prepare_v2(db, sqlPrereqs, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement for prerequisites
		while (sqlite3_step(stmt) == SQLITE_ROW) { // Execute the statement and iterate through the results
			course.prerequisites.push_back(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0))); // Get each prerequisite from the first column and add it to the course's prerequisites vector
        }
    }
    sqlite3_finalize(stmt);
    return true;
}

// Searches for courses in the database that match a given prefix and returns them as a vector of Course objects
vector<Course> DatabaseAdapter::searchCoursesByPrefix(const string& prefix) {
    vector<Course> results;
	const char* sql = "SELECT CourseNumber, Title FROM Courses WHERE CourseNumber LIKE ?"; // SQL query to search for courses by prefix
    sqlite3_stmt* stmt; 

	// Prepare the SQL statement with a wildcard search
	if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) { 
        string pattern = prefix + "%";
		sqlite3_bind_text(stmt, 1, pattern.c_str(), -1, SQLITE_STATIC); // Bind the prefix with a wildcard to the SQL statement

		while (sqlite3_step(stmt) == SQLITE_ROW) { // Execute the statement and iterate through the results
            Course c;
			c.courseNumber = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)); // Get course number from the first column
			c.title = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)); // Get course title from the second column
            results.push_back(c);
        }
    }
	sqlite3_finalize(stmt); // Finalize the statement to release resources
    return results;
}

// Adds a new course to the database, including its prerequisites
bool DatabaseAdapter::addCourse(const Course& course) {
	const char* sqlCourse = "INSERT INTO Courses (CourseNumber, Title) VALUES (?, ?)"; // SQL query to insert a new course
	const char* sqlPrereq = "INSERT INTO Prerequisites (CourseNumber, Prerequisite) VALUES (?, ?)"; // SQL query to insert a prerequisite for a course
    sqlite3_stmt* stmt;

    // Insert course
    if (sqlite3_prepare_v2(db, sqlCourse, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, course.courseNumber.c_str(), -1, SQLITE_STATIC);  // Bind the course number to the SQL statement
		sqlite3_bind_text(stmt, 2, course.title.c_str(), -1, SQLITE_STATIC);  // Bind the course title to the SQL statement
		if (sqlite3_step(stmt) != SQLITE_DONE) { // Execute the statement and check if it was successful
            sqlite3_finalize(stmt);
            return false;
        }
    }
    sqlite3_finalize(stmt);

    // Insert prerequisites
    for (const auto& prereq : course.prerequisites) {
		if (sqlite3_prepare_v2(db, sqlPrereq, -1, &stmt, nullptr) == SQLITE_OK) { // Prepare the SQL statement for inserting prerequisites
			sqlite3_bind_text(stmt, 1, course.courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement
			sqlite3_bind_text(stmt, 2, prereq.c_str(), -1, SQLITE_STATIC); // Bind the prerequisite to the SQL statement
			sqlite3_step(stmt); // Execute the statement to insert the prerequisite
        }
        sqlite3_finalize(stmt);
    }

    return true;
}

// Deletes a course and its prerequisites from the database based on the course number.
bool DatabaseAdapter::updateCourse(const Course& course) {
	const char* sqlUpdateTitle = "UPDATE Courses SET Title = ? WHERE CourseNumber = ?"; // SQL query to update the course title
	const char* sqlDeletePrereqs = "DELETE FROM Prerequisites WHERE CourseNumber = ?"; // SQL query to delete prerequisites for the course
	const char* sqlInsertPrereq = "INSERT INTO Prerequisites (CourseNumber, Prerequisite) VALUES (?, ?)"; // SQL query to insert a prerequisite for the course
	sqlite3_stmt* stmt; // Prepare the SQL statement for updating the course title

    // Update course title
    if (sqlite3_prepare_v2(db, sqlUpdateTitle, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, course.title.c_str(), -1, SQLITE_STATIC); // Bind the new title to the SQL statement
		sqlite3_bind_text(stmt, 2, course.courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement
		if (sqlite3_step(stmt) != SQLITE_DONE) { // Execute the statement and check if it was successful
			sqlite3_finalize(stmt); // Finalize the statement to release resources
            return false;
        }
    }
    sqlite3_finalize(stmt);

    // Delete old prerequisites
    if (sqlite3_prepare_v2(db, sqlDeletePrereqs, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, course.courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement for deleting prerequisites
        sqlite3_step(stmt);
    }
    sqlite3_finalize(stmt); 

    // Insert new prerequisites
    for (const auto& prereq : course.prerequisites) {
		if (sqlite3_prepare_v2(db, sqlInsertPrereq, -1, &stmt, nullptr) == SQLITE_OK) { // Prepare the SQL statement for inserting prerequisites
			sqlite3_bind_text(stmt, 1, course.courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement
			sqlite3_bind_text(stmt, 2, prereq.c_str(), -1, SQLITE_STATIC); // Bind the course number and prerequisite to the SQL statement
            sqlite3_step(stmt); 
        }
        sqlite3_finalize(stmt);
    }

    return true;
}

// Updates the prerequisites for a course in the database based on the course number and a vector of prerequisite course numbers.
bool DatabaseAdapter::updatePrerequisites(const std::string& courseNumber, const std::vector<std::string>& prereqs) {
	const char* sqlDelete = "DELETE FROM Prerequisites WHERE CourseNumber = ?"; // SQL query to delete existing prerequisites for the course
	const char* sqlInsert = "INSERT INTO Prerequisites (CourseNumber, Prerequisite) VALUES (?, ?)"; // SQL query to insert a new prerequisite for the course
    sqlite3_stmt* stmt;

    // Delete existing prereqs
    if (sqlite3_prepare_v2(db, sqlDelete, -1, &stmt, nullptr) == SQLITE_OK) { 
		sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement for deleting prerequisites
        sqlite3_step(stmt); 
    }
    sqlite3_finalize(stmt);

    // Insert new ones
    for (const auto& prereq : prereqs) {
        if (sqlite3_prepare_v2(db, sqlInsert, -1, &stmt, nullptr) == SQLITE_OK) {
			sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement
			sqlite3_bind_text(stmt, 2, prereq.c_str(), -1, SQLITE_STATIC); // Bind the prerequisite to the SQL statement
            sqlite3_step(stmt);
        }
        sqlite3_finalize(stmt);
    }

    return true;
}

// Deletes a course and its prerequisites from the database based on the course number.
bool DatabaseAdapter::deleteCourse(const std::string& courseNumber) {
	const char* sqlDeletePrereqs = "DELETE FROM Prerequisites WHERE CourseNumber = ?"; // SQL query to delete prerequisites for the course
	const char* sqlDeleteCourse = "DELETE FROM Courses WHERE CourseNumber = ?"; // SQL query to delete the course itself
    sqlite3_stmt* stmt;
    bool success = true;

    // Delete from Prerequisites
    if (sqlite3_prepare_v2(db, sqlDeletePrereqs, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement for deleting prerequisites
		success &= sqlite3_step(stmt) == SQLITE_DONE; // Execute the statement and check if it was successful
    }
    sqlite3_finalize(stmt);

    // Delete from Courses
    if (sqlite3_prepare_v2(db, sqlDeleteCourse, -1, &stmt, nullptr) == SQLITE_OK) {
		sqlite3_bind_text(stmt, 1, courseNumber.c_str(), -1, SQLITE_STATIC); // Bind the course number to the SQL statement for deleting the course
		success &= sqlite3_step(stmt) == SQLITE_DONE; // Execute the statement and check if it was successful
    }
    sqlite3_finalize(stmt);

    return success;
}

// Executes a SQL query and returns true if successful, false otherwise.
bool DatabaseAdapter::executeQuery(const string& sql) {
	char* errMsg = nullptr; // Pointer to hold error message if the query fails
	if (sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg) != SQLITE_OK) { // Execute the SQL query
		cerr << "SQL error: " << errMsg << endl; // Print error message if the query fails
		sqlite3_free(errMsg); // Free the error message memory
        return false;
    }
    return true;
}
