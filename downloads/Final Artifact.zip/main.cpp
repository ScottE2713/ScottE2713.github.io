//============================================================================
// File        : main.cpp
// Author      : Scott Enos
// Description : Entry point of the Advising Program.
//============================================================================

#include "AdvisingProgram.h"
#include <iostream>
#include "DatabaseAdapter.h"

using namespace std;

int main() {
    AdvisingProgram program; // Create an instance of AdvisingProgram
	try { // Attempt to display the menu and handle user interactions
        
		DatabaseAdapter db("advising.db"); // Create an instance of DatabaseAdapter with the database file path -- Creates the database if it doesn't exist
        if (!db.open()) {
            std::cerr << "Failed to open database." << std::endl;
            return 1;
        }

        std::cout << "Database initialized...\n\n";

        program.displayMenu();
    }
    catch (...) {
		cout << "An unexpected error occurred. Please try again." << endl; // Catch any unexpected exceptions
		return 1; // Return a non-zero value to indicate an error
    }
    return 0;
}