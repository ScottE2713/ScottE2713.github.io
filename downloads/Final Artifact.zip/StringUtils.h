#include <algorithm>
#include <cctype>
#include <locale>
#include <regex>
#include <sstream>
#include <vector>

inline std::string trim(const std::string& s) { // Trims leading and trailing whitespace from a string
	if (s.empty()) return s; // If the string is empty, return it as is

	auto start = s.begin(); // Start from the beginning of the string
	while (start != s.end() && std::isspace(*start)) start++; // Move the start iterator forward until a non-whitespace character is found

	auto end = s.end(); // Start from the end of the string
	while (end != start && std::isspace(*(end - 1))) end--; // Move the end iterator backward until a non-whitespace character is found

	return std::string(start, end); // Return the trimmed string
}

inline std::string toUpper(const std::string& s) { // Converts a string to uppercase
	std::string result = s; // Create a copy of the input string
	std::transform(result.begin(), result.end(), result.begin(), ::toupper); // Transform each character to uppercase
	return result;
}

inline std::string removeHyphens(const std::string& s) { // Removes hyphens from a string
	std::string result = s; // Create a copy of the input string
	result.erase(std::remove(result.begin(), result.end(), '-'), result.end()); // Remove all hyphens from the string
	return result;
}

inline bool isValidCourseNumber(const std::string& input) { // Checks if a course number is valid (e.g., CS101)
	static const std::regex validFormat("[A-Z]{2,4}\\d{3}"); // Define valid format: 2�4 letters followed by 3 digits
	return std::regex_match(input, validFormat); // Return true if input matches the format
}

inline bool isValidTitle(const std::string& title) { // Checks if a course title is valid
	return !title.empty() && title.length() <= 100 && // Ensure title is not empty and not too long
		std::regex_match(title, std::regex("^[A-Za-z0-9 ,.'-]+$")); // Allow only letters, digits, and basic punctuation
}

inline std::vector<std::string> splitPrerequisites(const std::string& input) { // Splits a comma-separated prerequisite string into a vector
	std::vector<std::string> prereqs; // Vector to store cleaned prerequisites
	std::stringstream ss(input); // Stream to tokenize the input
	std::string token;

	while (getline(ss, token, ',')) { // Extract each prerequisite by comma
		token = removeHyphens(toUpper(trim(token))); // Clean the token: trim, uppercase, remove hyphens
		if (!token.empty() && isValidCourseNumber(token)) { // Only add if valid
			prereqs.push_back(token); // Add to the vector
		}
	}
	return prereqs; // Return the final list of cleaned prerequisites
}

// Sanitizes input by trimming, converting to uppercase, and removing hyphens
inline std::string sanitize(const std::string& s) {
	return removeHyphens(toUpper(trim(s)));
}
