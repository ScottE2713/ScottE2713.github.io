#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>

// Structure to hold information about a course
struct Course {
    std::string courseNumber; // Unique identifier for the course
    std::string title; // Title of the course
    std::vector<std::string> prerequisites; // List of prerequisites for the course
};

#endif
